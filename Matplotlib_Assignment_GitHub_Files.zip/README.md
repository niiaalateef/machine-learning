# 📊 Python Data Visualization with Matplotlib

## Employee Sales Visualization

This project demonstrates four common chart types using **Matplotlib** and **Pandas**.

## 📁 Dataset
`employee_sales.csv`

## 📈 Task 1 – Scatter Plot
Shows the relationship between employee experience and sales.

![Scatter Plot](Figure_1_scatterplot.png)

---

## 📊 Task 2 – Bar Chart
Compares total sales of each employee.

![Bar Chart](Figure_1-barchart.png)

---

## 📉 Task 3 – Histogram
Shows the distribution of employee sales.

![Histogram](Figure_1-histogram.png)

---

## 🥧 Task 4 – Pie Chart
Shows the department-wise employee distribution.

![Pie Chart](Figure_1-piechart.png)

---

## 🛠️ Technologies Used

- Python
- Pandas
- Matplotlib

## 📂 Project Structure

```text
.
├── employee_sales.csv
├── assignment.ipynb
├── README.md
├── Figure_1_scatterplot.png
├── Figure_1-barchart.png
├── Figure_1-histogram.png
└── Figure_1-piechart.png
```

## 📚 Learning Outcomes

- Create scatter plots
- Compare categories using bar charts
- Analyze distributions using histograms
- Visualize proportions with pie charts

## 👨‍💻 Author

**Name:** Your Name

⭐ Thanks for visiting!
